## Using Twitter Sentiment to Predict Stock Trends

#### Import Necessary Packages


```python
import nltk
import numpy as np
import pandas as pd
import datetime as dt
import seaborn as sns
import matplotlib.pyplot as plt
from nltk.util import ngrams
from os import listdir, getcwd
from collections import Counter
from os.path import isfile, join
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.naive_bayes import MultinomialNB
from nltk import wordpunct_tokenize, word_tokenize
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score, roc_curve, accuracy_score
```

#### Read in Data


```python
# Read in stock data.
stocks = pd.read_csv('stockData.csv')
```


```python
# Get Tweet data files.
onlyfiles = [f for f in listdir(getcwd()) if isfile(join(getcwd(), f))]
# Read and concatenate all twitter data files.
tweets = pd.concat([pd.read_csv(file) for file in [i for i in onlyfiles if 'tweetData' in i]])
```

### Data Cleaning

#### Clean Stocks Data


```python
# There are some duplicates that need to be removed in the stock data.
stocks = stocks.drop_duplicates(['ticker', 'Date'])[['ticker', 'Date', 'delta', 'delta_bin']]
```


```python
stocks['date'] = [dt.datetime.strptime(i, '%b %d, %Y').strftime('%Y-%m-%d') for i in stocks.Date]
stocks = stocks.drop('Date', 1)
```

#### Clean Twitter Data


```python
# Rename the columns and remove unnecessary columns.
tweets.columns = ['tweet', 'user', 'location', 'date', 'retweets', 'searchwords']
```


```python
# Grab the ticker symbol from stopwords
tweets['ticker'] = [i.split(' OR')[0] for i in tweets['searchwords']]
```


```python
# Grab the ticker symbol from stopwords
tweets = tweets.drop_duplicates(['tweet', 'date', 'ticker'])[['tweet', 'date', 'ticker']]
```


```python
# Clean the tweets to remove stopwords and symobols.
sw = stopwords.words('english')
def clean_text(x):
    x = x.lower()
    words = x.split()
    words = [w for w in words if w not in sw]
    words = [w for w in words if w.isalpha()]
    return " ".join(words)

tweets['tweet'] = tweets['tweet'].apply(clean_text)
```


```python
# Create one string from all of the tweets regarding that company on that day.
tweets['date'] = [i.split(' ')[0] for i in tweets['date']]
tweets_grouped = tweets.groupby(['date', 'ticker'])
grouped_lists = tweets_grouped["tweet"].agg(lambda column: " ".join(column))
tweets = grouped_lists.reset_index(name="tweet")
```

#### Combine Data Frames


```python
# Merge the DataFrames together to see if tweets from the day affect closing price
dataFinal = tweets.merge(stocks, left_on=['date', 'ticker'], right_on=[ 'date', 'ticker'])
```


```python
dataFinal.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>ticker</th>
      <th>tweet</th>
      <th>delta</th>
      <th>delta_bin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2020-11-16</td>
      <td>AAP</td>
      <td>highlights annual mobil twelve hours sebring p...</td>
      <td>-4.44</td>
      <td>down</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2020-11-16</td>
      <td>ANTM</td>
      <td>today released legendary anthem empowerment no...</td>
      <td>-2.77</td>
      <td>down</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2020-11-16</td>
      <td>BLK</td>
      <td>years ago michael jordan ridiculous line vs pt...</td>
      <td>-6.07</td>
      <td>down</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2020-11-16</td>
      <td>CARR</td>
      <td>south korean korean air says buy smaller troub...</td>
      <td>1.26</td>
      <td>up</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2020-11-16</td>
      <td>CE</td>
      <td>great post awhile ago rise nazi hippies worth ...</td>
      <td>2.38</td>
      <td>up</td>
    </tr>
  </tbody>
</table>
</div>



### EDA

#### Get Word Counts


```python
long_content = " ".join(list(dataFinal['tweet'])).split()
c = Counter(long_content)
wc_total = pd.DataFrame(c.items(), columns=['word', 'count'])
wc_total.sort_values(by='count', ascending=False).head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>word</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>222</td>
      <td>new</td>
      <td>150</td>
    </tr>
    <tr>
      <td>548</td>
      <td>johnson</td>
      <td>131</td>
    </tr>
    <tr>
      <td>662</td>
      <td>key</td>
      <td>130</td>
    </tr>
    <tr>
      <td>230</td>
      <td>cop</td>
      <td>124</td>
    </tr>
    <tr>
      <td>1188</td>
      <td>walmart</td>
      <td>104</td>
    </tr>
    <tr>
      <td>75</td>
      <td>says</td>
      <td>91</td>
    </tr>
    <tr>
      <td>70</td>
      <td>trump</td>
      <td>90</td>
    </tr>
    <tr>
      <td>15</td>
      <td>anthem</td>
      <td>85</td>
    </tr>
    <tr>
      <td>49</td>
      <td>people</td>
      <td>84</td>
    </tr>
    <tr>
      <td>20</td>
      <td>one</td>
      <td>83</td>
    </tr>
  </tbody>
</table>
</div>




```python
for_plot = wc_total.sort_values(by='count',ascending=False).head(15)
```


```python
plt.figure(figsize=(12,5))
sns.barplot(x='word', y='count',data=for_plot, palette='cividis')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x19d5237ae88>




![png](output_23_1.png)


#### Count bigrams/trigrams


```python
bigrams = ngrams(long_content, 2)
```


```python
c2 = Counter(bigrams)
```


```python
bic = pd.DataFrame(c2.items(), columns=['word','count'])
```


```python
bic.sort_values(by='count',ascending=False).head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>word</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>692</td>
      <td>(boris, johnson)</td>
      <td>49</td>
    </tr>
    <tr>
      <td>533</td>
      <td>(general, motors)</td>
      <td>41</td>
    </tr>
    <tr>
      <td>5389</td>
      <td>(tyson, foods)</td>
      <td>31</td>
    </tr>
    <tr>
      <td>47</td>
      <td>(national, anthem)</td>
      <td>29</td>
    </tr>
    <tr>
      <td>9341</td>
      <td>(black, friday)</td>
      <td>12</td>
    </tr>
    <tr>
      <td>1124</td>
      <td>(joe, biden)</td>
      <td>12</td>
    </tr>
    <tr>
      <td>7303</td>
      <td>(many, workers)</td>
      <td>12</td>
    </tr>
    <tr>
      <td>1382</td>
      <td>(paypal, venmo)</td>
      <td>11</td>
    </tr>
    <tr>
      <td>2276</td>
      <td>(home, depot)</td>
      <td>11</td>
    </tr>
    <tr>
      <td>6107</td>
      <td>(motors, says)</td>
      <td>11</td>
    </tr>
    <tr>
      <td>7304</td>
      <td>(workers, would)</td>
      <td>11</td>
    </tr>
    <tr>
      <td>262</td>
      <td>(black, man)</td>
      <td>11</td>
    </tr>
    <tr>
      <td>1381</td>
      <td>(cashapp, paypal)</td>
      <td>10</td>
    </tr>
    <tr>
      <td>1060</td>
      <td>(donald, trump)</td>
      <td>10</td>
    </tr>
    <tr>
      <td>6036</td>
      <td>(hazard, pay)</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
</div>




```python
trigrams = ngrams(long_content, 3)
c3 = Counter(trigrams)
pd.DataFrame(c3.items(), columns=['word','count']).sort_values(by='count', ascending=False).head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>word</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>7649</td>
      <td>(many, workers, would)</td>
      <td>11</td>
    </tr>
    <tr>
      <td>6380</td>
      <td>(general, motors, says)</td>
      <td>9</td>
    </tr>
    <tr>
      <td>3530</td>
      <td>(alpha, phi, alpha)</td>
      <td>9</td>
    </tr>
    <tr>
      <td>1410</td>
      <td>(post, cashapp, paypal)</td>
      <td>9</td>
    </tr>
    <tr>
      <td>1411</td>
      <td>(cashapp, paypal, venmo)</td>
      <td>8</td>
    </tr>
    <tr>
      <td>1412</td>
      <td>(paypal, venmo, bitcoin)</td>
      <td>8</td>
    </tr>
    <tr>
      <td>47</td>
      <td>(sing, national, anthem)</td>
      <td>7</td>
    </tr>
    <tr>
      <td>2423</td>
      <td>(omega, psi, phi)</td>
      <td>7</td>
    </tr>
    <tr>
      <td>7349</td>
      <td>(mission, army, vet)</td>
      <td>7</td>
    </tr>
    <tr>
      <td>7650</td>
      <td>(workers, would, get)</td>
      <td>6</td>
    </tr>
    <tr>
      <td>12894</td>
      <td>(penguin, random, house)</td>
      <td>6</td>
    </tr>
    <tr>
      <td>14277</td>
      <td>(near, today, worth)</td>
      <td>6</td>
    </tr>
    <tr>
      <td>14276</td>
      <td>(nio, near, today)</td>
      <td>6</td>
    </tr>
    <tr>
      <td>14278</td>
      <td>(today, worth, general)</td>
      <td>6</td>
    </tr>
    <tr>
      <td>14275</td>
      <td>(startup, nio, near)</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



#### Sentiment


```python
# Read in sentiments
sentiments = pd.read_csv('LoughranMcDonald_MasterDictionary_2018.csv')
sentiments['word'] = [str(i).lower() for i in sentiments['Word']]
sentiments = sentiments.drop('Word', 1)
```


```python
sentiments['sentiment'] = ['positive' if int(sentiments['Positive'][i]) > 0 else 'negative' if int(sentiments['Negative'][i]) > 0 else 'neutral' for i in range(len(sentiments['Positive']))]
sentiments = sentiments[['word', 'sentiment']]
```


```python
new = pd.merge(wc_total, sentiments, how='inner')
new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>word</th>
      <th>count</th>
      <th>sentiment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>highlights</td>
      <td>3</td>
      <td>neutral</td>
    </tr>
    <tr>
      <td>1</td>
      <td>annual</td>
      <td>5</td>
      <td>neutral</td>
    </tr>
    <tr>
      <td>2</td>
      <td>twelve</td>
      <td>2</td>
      <td>neutral</td>
    </tr>
    <tr>
      <td>3</td>
      <td>hours</td>
      <td>7</td>
      <td>neutral</td>
    </tr>
    <tr>
      <td>4</td>
      <td>presented</td>
      <td>3</td>
      <td>neutral</td>
    </tr>
  </tbody>
</table>
</div>




```python
new['sentiment'].value_counts()
```




    neutral     5134
    negative     348
    positive     100
    Name: sentiment, dtype: int64




```python
p = new[new['sentiment']=='positive'].sort_values(by='count',ascending=False).head(10)
n = new[new['sentiment']=='negative'].sort_values(by='count',ascending=False).head(10)
```


```python
plt.figure(figsize=(12,5))
sns.barplot(x='word', y='count',data=p,palette='spring')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x19d5341b148>




![png](output_36_1.png)



```python
plt.figure(figsize=(12,5))
sns.barplot(x='word', y='count',data=n, palette='winter')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x19d53429a08>




![png](output_37_1.png)


### Create Features

#### Generate Sentiment for each Tweet


```python
def pos_pct(x):
    try:
        pos = x.positive
    except:
        pos = 0
    try:
        neg = x.negative
    except:
        neg = 0
    try:
        neu = x.neutral
    except:
        neu = 0
    try:
        pct_pos = pos / (pos + neg + neu)
    except:
        pct_pos = 0
    return(pct_pos)

def neg_pct(x):
    try:
        pos = x.positive
    except:
        pos = 0
    try:
        neg = x.negative
    except:
        neg = 0
    try:
        neu = x.neutral
    except:
        neu = 0
    try:
        pct_neg = neg / (pos + neg + neu)
    except:
        pct_neg = 0
    return(pct_neg)
```


```python
wn = WordNetLemmatizer()
def process_text(x):
    x = x.lower()
    tokens = wordpunct_tokenize(x)
    tokens = [tok for tok in tokens if tok.isalnum()]
    tokens = [tok for tok in tokens if tok not in sw]
    tokens = [wn.lemmatize(tok) for tok in tokens]
    return(tokens)
```


```python
sent_pos = []
for tweet in dataFinal['tweet']:
    c = Counter(process_text(tweet))
    tmp = pd.DataFrame(c.items(), columns=['word','count'])
    tmp = tmp.merge(sentiments, how='inner')
    x = tmp['sentiment'].value_counts()
    sent_pos.append(pos_pct(x))
```


```python
sent_neg = []
for tweet in dataFinal['tweet']:
    c = Counter(process_text(tweet))
    tmp = pd.DataFrame(c.items(), columns=['word','count'])
    tmp = tmp.merge(sentiments, how='inner')
    x = tmp['sentiment'].value_counts()
    sent_neg.append(neg_pct(x))
```


```python
dataFinal['sent_pos'] = sent_pos
dataFinal['sent_neg'] = sent_neg
```


```python
dataFinal.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>ticker</th>
      <th>tweet</th>
      <th>delta</th>
      <th>delta_bin</th>
      <th>sent_pos</th>
      <th>sent_neg</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2020-11-16</td>
      <td>AAP</td>
      <td>highlights annual mobil twelve hours sebring p...</td>
      <td>-4.44</td>
      <td>down</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2020-11-16</td>
      <td>ANTM</td>
      <td>today released legendary anthem empowerment no...</td>
      <td>-2.77</td>
      <td>down</td>
      <td>0.014085</td>
      <td>0.014085</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2020-11-16</td>
      <td>BLK</td>
      <td>years ago michael jordan ridiculous line vs pt...</td>
      <td>-6.07</td>
      <td>down</td>
      <td>0.000000</td>
      <td>0.074074</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2020-11-16</td>
      <td>CARR</td>
      <td>south korean korean air says buy smaller troub...</td>
      <td>1.26</td>
      <td>up</td>
      <td>0.000000</td>
      <td>0.125000</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2020-11-16</td>
      <td>CE</td>
      <td>great post awhile ago rise nazi hippies worth ...</td>
      <td>2.38</td>
      <td>up</td>
      <td>0.041667</td>
      <td>0.041667</td>
    </tr>
  </tbody>
</table>
</div>



### Semantic Model Approach


```python
train, test = train_test_split(dataFinal, 
                               test_size=.3,
                               stratify=dataFinal.delta_bin, 
                               random_state=123)
```


```python
y_train = (train['delta_bin'] == 'up').astype(int)
y_test = (test['delta_bin'] == 'up').astype(int)
```

#### Generate TF-IDF Features


```python
tfidf = TfidfVectorizer(max_df = 0.95)
```


```python
tfidf.fit(train['tweet'])
X_train = tfidf.transform(train['tweet'])
X_test = tfidf.transform(test['tweet'])
```

#### Multinomial Naive Bayes


```python
nb = MultinomialNB()
nb.fit(X_train, y_train)
yhat_test = nb.predict(X_test)
confusion_matrix(y_test, yhat_test)
```




    array([[28, 58],
           [27, 68]], dtype=int64)




```python
accuracy_score(y_test, yhat_test)
```




    0.5303867403314917




```python
f1_score(y_test, yhat_test)
```




    0.6153846153846154




```python
precision_score(y_test, yhat_test)
```




    0.5396825396825397



#### Random Forest


```python
rf = RandomForestClassifier(100)
rf.fit(X_train, y_train)
yhat = rf.predict(X_test)
confusion_matrix(y_test, yhat)
```




    array([[39, 47],
           [29, 66]], dtype=int64)




```python
accuracy_score(y_test, yhat)
```




    0.580110497237569




```python
f1_score(y_test, yhat)
```




    0.6346153846153847




```python
precision_score(y_test, yhat)
```




    0.584070796460177



### Sentiment Analysis Approach


```python
train, test = train_test_split(dataFinal, 
                               test_size=.3,
                               stratify=dataFinal.delta_bin, 
                               random_state=123)
```


```python
X_train = train[['sent_pos', 'sent_neg']]
X_test = test[['sent_pos', 'sent_neg']]
```


```python
y_train = (train['delta_bin'] == 'up').astype(int)
y_test = (test['delta_bin'] == 'up').astype(int)
```

#### Logistic Regression Using Sentiment


```python
lm = LogisticRegression(solver='liblinear', random_state=123)
lm.fit(X_train, y_train)
yhat = lm.predict(X_test)
confusion_matrix(y_test, yhat)
```




    array([[ 0, 86],
           [ 0, 95]], dtype=int64)




```python
accuracy_score(y_test, yhat)
```




    0.5248618784530387




```python
f1_score(y_test, yhat)
```




    0.6884057971014492




```python
precision_score(y_test, yhat)
```




    0.5248618784530387



#### Random Forest Using Sentiment


```python
rf = RandomForestClassifier(100)
rf.fit(X_train, y_train)
yhat = rf.predict(X_test)
confusion_matrix(y_test, yhat)
```




    array([[23, 63],
           [29, 66]], dtype=int64)




```python
accuracy_score(y_test, yhat)
```




    0.49171270718232046




```python
f1_score(y_test, yhat)
```




    0.5892857142857144




```python
precision_score(y_test, yhat)
```




    0.5116279069767442




```python

```
